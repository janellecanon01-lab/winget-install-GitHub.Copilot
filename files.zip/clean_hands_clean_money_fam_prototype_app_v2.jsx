import { useState, useEffect } from "react"
import { AlertCircle, CheckCircle, Clock, TrendingUp, Users, DollarSign, Building2, Zap } from "lucide-react"

// ============================================
// CONSTANTS
// ============================================
const INITIAL_BALANCE = 2500
const MIN_DEPOSIT = 1
const MAX_DEPOSIT = 50000
const MIN_LOAN = 100
const MAX_LOAN = 100000
const MESSAGE_DISPLAY_TIME = 4000
const STATS_UPDATE_DELAY = 500

// ============================================
// NOTIFICATION SYSTEM
// ============================================
function Notification({ message, type, onDismiss }) {
  useEffect(() => {
    const timer = setTimeout(onDismiss, MESSAGE_DISPLAY_TIME)
    return () => clearTimeout(timer)
  }, [onDismiss])

  const bgColor = {
    success: "bg-emerald-500/20 border-emerald-500/50 text-emerald-300",
    error: "bg-red-500/20 border-red-500/50 text-red-300",
    warning: "bg-yellow-500/20 border-yellow-500/50 text-yellow-300",
    info: "bg-blue-500/20 border-blue-500/50 text-blue-300"
  }[type]

  const icon = {
    success: <CheckCircle className="w-5 h-5" />,
    error: <AlertCircle className="w-5 h-5" />,
    warning: <AlertCircle className="w-5 h-5" />,
    info: <Clock className="w-5 h-5" />
  }[type]

  return (
    <div className={`flex items-center gap-3 border rounded-2xl p-4 mb-4 animate-in fade-in slide-in-from-top-2 ${bgColor}`}>
      {icon}
      <div className="flex-1">{message}</div>
      <button
        onClick={onDismiss}
        className="text-xs opacity-70 hover:opacity-100"
      >
        ✕
      </button>
    </div>
  )
}

// ============================================
// LOAN APPLICATION COMPONENT
// ============================================
function LoanApplicationForm({ onSubmit, isLoading }) {
  const [loanAmount, setLoanAmount] = useState(500)
  const [purpose, setPurpose] = useState("")

  const handleSubmit = () => {
    onSubmit({ amount: loanAmount, purpose })
    setLoanAmount(500)
    setPurpose("")
  }

  const isValid = loanAmount >= MIN_LOAN && loanAmount <= MAX_LOAN && purpose.trim().length > 0

  return (
    <div className="space-y-4">
      <div>
        <label className="text-sm text-gray-400 block mb-2">Requested Amount ($)</label>
        <div className="flex gap-2">
          <input
            type="number"
            min={MIN_LOAN}
            max={MAX_LOAN}
            value={loanAmount}
            onChange={(e) => setLoanAmount(Math.max(MIN_LOAN, Math.min(MAX_LOAN, Number(e.target.value))))}
            className="flex-1 bg-black border border-gray-700 rounded-2xl p-4 text-white focus:border-emerald-500 focus:outline-none transition"
            aria-label="Loan amount in dollars"
            disabled={isLoading}
          />
          <div className="text-gray-500 text-sm flex items-center px-4 bg-black border border-gray-700 rounded-2xl">
            Range: ${MIN_LOAN}-${MAX_LOAN.toLocaleString()}
          </div>
        </div>
      </div>

      <div>
        <label className="text-sm text-gray-400 block mb-2">Loan Purpose</label>
        <input
          type="text"
          value={purpose}
          onChange={(e) => setPurpose(e.target.value)}
          placeholder="e.g., Small business equipment"
          className="w-full bg-black border border-gray-700 rounded-2xl p-4 text-white focus:border-emerald-500 focus:outline-none transition"
          aria-label="Purpose of loan"
          disabled={isLoading}
        />
      </div>

      <button
        onClick={handleSubmit}
        disabled={!isValid || isLoading}
        className="w-full bg-emerald-500 hover:bg-emerald-400 disabled:bg-gray-600 disabled:cursor-not-allowed text-black font-semibold px-6 py-3 rounded-2xl transition"
        aria-label="Submit loan application"
      >
        {isLoading ? "Processing..." : "Submit Application"}
      </button>
    </div>
  )
}

// ============================================
// DEPOSIT COMPONENT
// ============================================
function DepositSection({ balance, onDeposit, isLoading }) {
  const [depositAmount, setDepositAmount] = useState(100)

  const handleDeposit = () => {
    onDeposit(depositAmount)
    setDepositAmount(100)
  }

  const isValid = depositAmount >= MIN_DEPOSIT && depositAmount <= MAX_DEPOSIT

  return (
    <div className="bg-black border border-emerald-500/20 rounded-3xl p-6 space-y-4">
      <div>
        <p className="text-gray-400 text-sm">Community Wallet</p>
        <h2 className="text-5xl font-bold mt-2">${balance.toLocaleString()}</h2>
      </div>

      <div>
        <label className="text-sm text-gray-400 block mb-2">Deposit Amount ($)</label>
        <input
          type="number"
          min={MIN_DEPOSIT}
          max={MAX_DEPOSIT}
          value={depositAmount}
          onChange={(e) => setDepositAmount(Math.max(MIN_DEPOSIT, Math.min(MAX_DEPOSIT, Number(e.target.value))))}
          className="w-full bg-gray-900 border border-gray-700 rounded-2xl p-4 text-white focus:border-emerald-500 focus:outline-none transition"
          aria-label="Deposit amount"
          disabled={isLoading}
        />
        <p className="text-xs text-gray-500 mt-1">Range: ${MIN_DEPOSIT}-${MAX_DEPOSIT.toLocaleString()}</p>
      </div>

      <button
        onClick={handleDeposit}
        disabled={!isValid || isLoading}
        className="w-full bg-emerald-500 hover:bg-emerald-400 disabled:bg-gray-600 disabled:cursor-not-allowed text-black font-semibold py-3 rounded-2xl transition"
        aria-label="Deposit funds to community wallet"
      >
        {isLoading ? "Processing..." : `Deposit $${depositAmount.toLocaleString()}`}
      </button>
    </div>
  )
}

// ============================================
// LOAN HISTORY COMPONENT
// ============================================
function LoanHistory({ loans }) {
  if (loans.length === 0) {
    return (
      <div className="text-center py-8 text-gray-400">
        <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
        <p>No loan applications yet</p>
      </div>
    )
  }

  return (
    <div className="space-y-3 max-h-96 overflow-y-auto">
      {loans.map((loan) => (
        <div key={loan.id} className="bg-black rounded-2xl p-4 border border-gray-700 hover:border-emerald-500/50 transition">
          <div className="flex justify-between items-start gap-4">
            <div className="flex-1">
              <p className="font-semibold text-white">${loan.amount.toLocaleString()}</p>
              <p className="text-sm text-gray-400">{loan.purpose}</p>
              <p className="text-xs text-gray-500 mt-1">{new Date(loan.appliedDate).toLocaleDateString()}</p>
            </div>
            <div className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap ${
              loan.status === "pending" ? "bg-yellow-500/20 text-yellow-300" :
              loan.status === "approved" ? "bg-emerald-500/20 text-emerald-300" :
              "bg-red-500/20 text-red-300"
            }`}>
              {loan.status.charAt(0).toUpperCase() + loan.status.slice(1)}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

// ============================================
// TRANSACTION HISTORY COMPONENT
// ============================================
function TransactionHistory({ transactions }) {
  if (transactions.length === 0) {
    return (
      <div className="text-center py-8 text-gray-400">
        <DollarSign className="w-12 h-12 mx-auto mb-3 opacity-50" />
        <p>No transactions yet</p>
      </div>
    )
  }

  return (
    <div className="space-y-3 max-h-64 overflow-y-auto">
      {transactions.map((tx) => (
        <div key={tx.id} className="bg-black rounded-2xl p-4 border border-gray-700">
          <div className="flex justify-between items-center">
            <div>
              <p className="font-semibold text-white capitalize">{tx.type}</p>
              <p className="text-xs text-gray-500">{new Date(tx.timestamp).toLocaleString()}</p>
            </div>
            <p className={`font-bold text-lg ${tx.type === "deposit" ? "text-emerald-300" : "text-gray-300"}`}>
              {tx.type === "deposit" ? "+" : ""} ${tx.amount.toLocaleString()}
            </p>
          </div>
        </div>
      ))}
    </div>
  )
}

// ============================================
// MAIN COMPONENT
// ============================================
export default function CleanHandsPrototype() {
  // STATE
  const [balance, setBalance] = useState(INITIAL_BALANCE)
  const [loans, setLoans] = useState([])
  const [transactions, setTransactions] = useState([])
  const [notifications, setNotifications] = useState([])
  const [isLoading, setIsLoading] = useState(false)
  const [stats, setStats] = useState({
    totalAccounts: 1250,
    totalLoans: 2400000,
    communitiesServed: 18,
    growthRate: 24
  })

  // NOTIFICATION HELPER
  const addNotification = (message, type = "info") => {
    const id = Date.now()
    setNotifications(prev => [...prev, { id, message, type }])
  }

  const removeNotification = (id) => {
    setNotifications(prev => prev.filter(n => n.id !== id))
  }

  // DEPOSIT HANDLER
  const handleDeposit = (amount) => {
    setIsLoading(true)
    
    // Simulate API call
    setTimeout(() => {
      setBalance(prev => prev + amount)
      
      const newTransaction = {
        id: Date.now(),
        type: "deposit",
        amount,
        timestamp: new Date().toISOString()
      }
      
      setTransactions(prev => [newTransaction, ...prev.slice(0, 19)]) // Keep last 20
      addNotification(`$${amount.toLocaleString()} deposited successfully!`, "success")
      setIsLoading(false)
      
      // Update stats
      setTimeout(() => {
        setStats(prev => ({
          ...prev,
          totalLoans: prev.totalLoans + amount
        }))
      }, STATS_UPDATE_DELAY)
    }, 800)
  }

  // LOAN APPLICATION HANDLER
  const handleLoanApplication = ({ amount, purpose }) => {
    if (amount < MIN_LOAN || amount > MAX_LOAN) {
      addNotification(`Loan amount must be between $${MIN_LOAN} and $${MAX_LOAN.toLocaleString()}`, "error")
      return
    }

    if (!purpose.trim()) {
      addNotification("Please provide a loan purpose", "error")
      return
    }

    setIsLoading(true)

    // Simulate API call and community review
    setTimeout(() => {
      const newLoan = {
        id: Date.now(),
        amount,
        purpose,
        status: "pending",
        appliedDate: new Date().toISOString(),
        approvalDate: null
      }

      setLoans(prev => [newLoan, ...prev])
      addNotification(`Loan application submitted for $${amount.toLocaleString()}. Community review pending.`, "info")
      setIsLoading(false)

      // Simulate auto-approval after 2 seconds for demo
      setTimeout(() => {
        setLoans(prev => prev.map(loan => 
          loan.id === newLoan.id 
            ? { ...loan, status: "approved", approvalDate: new Date().toISOString() }
            : loan
        ))
        addNotification(`Loan of $${amount.toLocaleString()} approved! Funds available for withdrawal.`, "success")
        
        // Update stats
        setStats(prev => ({
          ...prev,
          totalLoans: prev.totalLoans + amount,
          growthRate: Math.min(99, prev.growthRate + 1)
        }))
      }, 2000)
    }, 800)
  }

  const approvedLoansCount = loans.filter(l => l.status === "approved").length
  const pendingLoansCount = loans.filter(l => l.status === "pending").length

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* NOTIFICATIONS */}
        <div className="fixed top-6 right-6 z-50 space-y-2 max-w-md">
          {notifications.map(notif => (
            <Notification
              key={notif.id}
              message={notif.message}
              type={notif.type}
              onDismiss={() => removeNotification(notif.id)}
            />
          ))}
        </div>

        {/* HEADER */}
        <header className="border border-emerald-500/30 rounded-3xl p-8 bg-gradient-to-br from-gray-900 to-black shadow-2xl">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
            <div>
              <h1 className="text-5xl font-bold mb-4 tracking-tight">
                Clean Hands Clean Money FAM
              </h1>
              <p className="text-xl text-emerald-300 mb-4">
                Indigenous-Led Ethical Financial Infrastructure Prototype
              </p>
              <p className="text-gray-300 max-w-3xl leading-relaxed">
                A prototype platform demonstrating ethical banking concepts,
                community-centered finance, entrepreneurship support, and Indigenous-led
                economic development systems envisioned by Morley Moses Apooch.
              </p>
            </div>

            <DepositSection 
              balance={balance} 
              onDeposit={handleDeposit}
              isLoading={isLoading}
            />
          </div>
        </header>

        {/* PILLARS SECTION */}
        <section className="grid md:grid-cols-3 gap-4">
          <div className="bg-gray-900/70 rounded-2xl p-5 border border-gray-800 hover:border-emerald-500/30 transition">
            <div className="flex items-start gap-3">
              <Zap className="w-6 h-6 text-emerald-400 mt-1 flex-shrink-0" />
              <div>
                <h2 className="font-semibold text-xl mb-2">Clean Hands</h2>
                <p className="text-gray-300 text-sm leading-relaxed">
                  Ethical leadership, transparent governance, accountability,
                  and anti-corruption principles.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gray-900/70 rounded-2xl p-5 border border-gray-800 hover:border-emerald-500/30 transition">
            <div className="flex items-start gap-3">
              <DollarSign className="w-6 h-6 text-emerald-400 mt-1 flex-shrink-0" />
              <div>
                <h2 className="font-semibold text-xl mb-2">Clean Money</h2>
                <p className="text-gray-300 text-sm leading-relaxed">
                  Community-first investment models and responsible financial systems.
                </p>
              </div>
            </div>
          </div>

          <div className="bg-gray-900/70 rounded-2xl p-5 border border-gray-800 hover:border-emerald-500/30 transition">
            <div className="flex items-start gap-3">
              <Users className="w-6 h-6 text-emerald-400 mt-1 flex-shrink-0" />
              <div>
                <h2 className="font-semibold text-xl mb-2">FAM</h2>
                <p className="text-gray-300 text-sm leading-relaxed">
                  Building generational wealth, opportunity, and financial inclusion.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* MAIN CONTENT GRID */}
        <section className="grid lg:grid-cols-2 gap-6">
          {/* LOAN APPLICATION */}
          <div className="bg-gray-900 rounded-3xl p-6 border border-gray-800">
            <h2 className="text-3xl font-bold mb-6 flex items-center gap-2">
              <Building2 className="w-8 h-8 text-emerald-400" />
              Loan Application
            </h2>
            <LoanApplicationForm 
              onSubmit={handleLoanApplication}
              isLoading={isLoading}
            />
          </div>

          {/* DASHBOARD METRICS */}
          <div className="bg-gray-900 rounded-3xl p-6 border border-gray-800">
            <h2 className="text-3xl font-bold mb-6 flex items-center gap-2">
              <TrendingUp className="w-8 h-8 text-emerald-400" />
              Dashboard
            </h2>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-black rounded-2xl p-5 border border-emerald-500/20 hover:border-emerald-500/50 transition">
                <p className="text-gray-400 text-sm">Community Accounts</p>
                <h3 className="text-3xl font-bold mt-2">{stats.totalAccounts.toLocaleString()}</h3>
              </div>

              <div className="bg-black rounded-2xl p-5 border border-emerald-500/20 hover:border-emerald-500/50 transition">
                <p className="text-gray-400 text-sm">Small Business Loans</p>
                <h3 className="text-3xl font-bold mt-2">${(stats.totalLoans / 1000000).toFixed(1)}M</h3>
              </div>

              <div className="bg-black rounded-2xl p-5 border border-emerald-500/20 hover:border-emerald-500/50 transition">
                <p className="text-gray-400 text-sm">Communities Served</p>
                <h3 className="text-3xl font-bold mt-2">{stats.communitiesServed}</h3>
              </div>

              <div className="bg-black rounded-2xl p-5 border border-emerald-500/20 hover:border-emerald-500/50 transition">
                <p className="text-gray-400 text-sm">Projected Growth</p>
                <h3 className="text-3xl font-bold mt-2">+{stats.growthRate}%</h3>
              </div>
            </div>
          </div>
        </section>

        {/* HISTORY SECTIONS */}
        <section className="grid lg:grid-cols-2 gap-6">
          {/* LOAN HISTORY */}
          <div className="bg-gray-900 rounded-3xl p-6 border border-gray-800">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <Clock className="w-6 h-6 text-emerald-400" />
              Loan Applications ({loans.length})
            </h2>
            <div className="space-y-2">
              {pendingLoansCount > 0 && (
                <p className="text-sm text-yellow-300 mb-3">
                  {pendingLoansCount} application{pendingLoansCount !== 1 ? 's' : ''} pending review
                </p>
              )}
              <LoanHistory loans={loans} />
            </div>
          </div>

          {/* TRANSACTION HISTORY */}
          <div className="bg-gray-900 rounded-3xl p-6 border border-gray-800">
            <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
              <DollarSign className="w-6 h-6 text-emerald-400" />
              Recent Transactions ({transactions.length})
            </h2>
            <TransactionHistory transactions={transactions} />
          </div>
        </section>

        {/* FEATURES SECTION */}
        <section className="grid lg:grid-cols-2 gap-6">
          <div className="bg-gray-900 rounded-3xl p-6 border border-gray-800">
            <h2 className="text-2xl font-bold mb-4">Cybersecurity & Infrastructure</h2>
            <ul className="space-y-3 text-gray-300 leading-relaxed">
              <li>• Prototype anomaly detection concepts</li>
              <li>• DDoS-resistant architecture planning</li>
              <li>• Ethical banking infrastructure model</li>
              <li>• Community-protected digital systems</li>
              <li>• Long-term Indigenous fintech development</li>
            </ul>
          </div>

          <div className="bg-gray-900 rounded-3xl p-6 border border-gray-800">
            <h2 className="text-2xl font-bold mb-4">Founder & Protection</h2>

            <div className="space-y-3 text-gray-300">
              <p>
                Morley Moses Apooch<br />
                <span className="text-emerald-400">Founder & Originator</span><br />
                Yorkton, Saskatchewan, Canada
              </p>

              <div className="bg-black rounded-2xl p-5 border border-emerald-500/20 text-sm leading-relaxed text-gray-400">
                Copyright © 2026 Morley Moses Apooch. All Rights Reserved.<br /><br />

                Protected internationally under the Berne Convention for the Protection
                of Literary and Artistic Works.<br /><br />

                Digitally Signed by Morley Moses Apooch.<br /><br />

                Contact: apoochmorley@protonmail.com
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}