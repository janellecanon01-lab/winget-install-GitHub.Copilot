# Setup & Installation Guide

## Prerequisites
- Node.js 18+
- npm or yarn
- Git
- PostgreSQL 14+
- Redis 7+ (optional but recommended)

## Frontend Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Install Required Packages
```bash
npm install lucide-react axios zustand
npm install -D tailwindcss postcss autoprefixer
```

### 3. Configure Tailwind CSS
```bash
npx tailwindcss init -p
```

Update `tailwind.config.js`:
```javascript
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        emerald: {
          300: '#6ee7b7',
          400: '#34d399',
          500: '#10b981',
        }
      }
    },
  },
  plugins: [],
}
```

### 4. Update `package.json`
```json
{
  "name": "clean-hands-prototype",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "lint": "eslint src"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "lucide-react": "^0.263.1",
    "axios": "^1.4.0",
    "zustand": "^4.3.8"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.0.0",
    "vite": "^4.4.0",
    "tailwindcss": "^3.3.0",
    "postcss": "^8.4.24",
    "autoprefixer": "^10.4.14"
  }
}
```

### 5. Create `.env.local`
```bash
VITE_API_URL=http://localhost:3000/api/v1
VITE_ENVIRONMENT=development
```

### 6. Run Development Server
```bash
npm run dev
# Opens http://localhost:5173
```

---

## Backend Setup (Optional)

### 1. Create Backend Directory
```bash
mkdir clean-hands-api
cd clean-hands-api
npm init -y
```

### 2. Install Dependencies
```bash
npm install express cors dotenv pg bcryptjs jsonwebtoken
npm install -D nodemon
```

### 3. Create `.env`
```bash
PORT=3000
NODE_ENV=development
DATABASE_URL=postgresql://user:password@localhost:5432/clean_hands
JWT_SECRET=your-secret-key-here
JWT_EXPIRATION=24h
```

### 4. Basic Express Server
```javascript
// server.js
import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import pkg from 'pg'

dotenv.config()

const { Pool } = pkg
const app = express()

// Middleware
app.use(cors())
app.use(express.json())

// Database connection
const pool = new Pool({
  connectionString: process.env.DATABASE_URL
})

// Routes
app.get('/api/v1/health', (req, res) => {
  res.json({ status: 'ok' })
})

app.post('/api/v1/deposits', async (req, res) => {
  try {
    const { userId, amount } = req.body
    
    // Validate
    if (amount < 1 || amount > 50000) {
      return res.status(400).json({ 
        error: 'Invalid amount' 
      })
    }
    
    // Create transaction
    const result = await pool.query(
      'INSERT INTO transactions (user_id, type, amount) VALUES ($1, $2, $3) RETURNING *',
      [userId, 'deposit', amount]
    )
    
    res.json({ success: true, transaction: result.rows[0] })
  } catch (error) {
    res.status(500).json({ error: error.message })
  }
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
```

### 5. Database Setup
```bash
# Connect to PostgreSQL
psql postgresql://user@localhost/clean_hands

# Run migrations (or create manually)
CREATE TABLE users (
  id UUID PRIMARY KEY,
  email VARCHAR UNIQUE NOT NULL,
  password_hash VARCHAR NOT NULL,
  first_name VARCHAR,
  last_name VARCHAR,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE transactions (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  type VARCHAR,
  amount DECIMAL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE loans (
  id UUID PRIMARY KEY,
  user_id UUID REFERENCES users(id),
  amount DECIMAL,
  purpose VARCHAR,
  status VARCHAR,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### 6. Start Server
```bash
npm run dev
# Server runs on http://localhost:3000
```

---

## Docker Setup

### Dockerfile
```dockerfile
FROM node:18-alpine

WORKDIR /app

COPY package*.json ./
RUN npm install

COPY . .

EXPOSE 3000
CMD ["npm", "run", "dev"]
```

### docker-compose.yml
```yaml
version: '3.8'

services:
  api:
    build: .
    ports:
      - "3000:3000"
    environment:
      DATABASE_URL: postgresql://postgres:password@db:5432/clean_hands
    depends_on:
      - db

  db:
    image: postgres:14
    environment:
      POSTGRES_PASSWORD: password
      POSTGRES_DB: clean_hands
    volumes:
      - postgres_data:/var/lib/postgresql/data
    ports:
      - "5432:5432"

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"

volumes:
  postgres_data:
```

### Run with Docker
```bash
docker-compose up -d
```

---

## Testing Setup

### Install Testing Dependencies
```bash
npm install -D vitest @testing-library/react @testing-library/jest-dom
npm install -D cypress playwright
```

### Run Tests
```bash
# Unit tests
npm run test

# E2E tests
npx cypress open
npx playwright test
```

---

## Troubleshooting

### Issue: Port 3000 already in use
```bash
# Find process using port
lsof -i :3000

# Kill process
kill -9 <PID>
```

### Issue: CORS errors
Add to `.env`:
```bash
CORS_ORIGIN=http://localhost:5173,http://localhost:3000
```

### Issue: Database connection failed
```bash
# Verify PostgreSQL is running
pg_isready

# Check connection string
echo $DATABASE_URL
```

### Issue: Tailwind styles not applying
```bash
# Rebuild Tailwind
npm run dev
# Then hard refresh browser (Ctrl+Shift+R)
```

---

## Production Deployment

### Build Frontend
```bash
npm run build
# Output in `dist/` directory
```

### Deploy to Vercel
```bash
npm install -g vercel
vercel
```

### Deploy to AWS
```bash
# Create EC2 instance
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install -y nodejs

# Clone repo & deploy
git clone <repo>
cd clean-hands-api
npm install
npm run build
pm2 start server.js
```
