# Clean Hands Clean Money FAM - Technical Blueprints

## 1. System Architecture

### High-Level Overview
```
┌─────────────────────────────────────────────────────────────┐
│                     Frontend (React/Vite)                    │
│  - Component-based UI                                        │
│  - State Management (useState → Redux/Zustand)              │
│  - Real-time Notifications                                   │
│  - Responsive Design (Mobile-first)                          │
└──────────────────────────┬──────────────────────────────────┘
                           │ HTTPS/WSS
┌──────────────────────────▼──────────────────────────────────┐
│                    API Gateway (Auth)                        │
│  - JWT/OAuth2 Authentication                                 │
│  - Rate Limiting                                             │
│  - Request Validation                                        │
└──────────────────────────┬──────────────────────────────────┘
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
┌───────▼──────┐  ┌────────▼────────┐  ┌────▼──────────┐
│ Loan Service │  │ User Service    │  │ Community API │
│ - Underwriting│  │ - Profiles      │  │ - Analytics   │
│ - Approval   │  │ - Transactions  │  │ - Reports     │
│ - Tracking   │  │ - Verification  │  │ - Compliance  │
└───────┬──────┘  └────────┬────────┘  └────┬──────────┘
        │                  │                  │
        └──────────────────┼──────────────────┘
                           │
        ┌──────────────────▼──────────────────┐
        │  Database Layer (PostgreSQL)        │
        │  - Users                            │
        │  - Loans                            │
        │  - Transactions                     │
        │  - Communities                      │
        └──────────────────┬──────────────────┘
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
┌───────▼─────┐   ┌────────▼─────┐  ┌───────▼────┐
│Cache Layer  │   │ Message Queue │  │ S3 Storage │
│(Redis)      │   │(RabbitMQ)     │  │(Backups)   │
└─────────────┘   └────────────────┘  └────────────┘
```

### Component Hierarchy
```
CleanHandsPrototype (Main)
├── NotificationSystem
│   └── Notification (multiple instances)
├── Header
│   ├── BrandInfo
│   └── DepositSection
├── PillarsSection
│   ├── CleanHandsCard
│   ├── CleanMoneyCard
│   └── FAMCard
├── MainContent
│   ├── LoanApplicationForm
│   └── DashboardMetrics
├── HistorySection
│   ├── LoanHistory
│   │   └── LoanCard (multiple)
│   └── TransactionHistory
│       └── TransactionCard (multiple)
└── FooterSection
    ├── CybersecurityInfo
    └── FounderInfo
```

---

## 2. Data Models & Schemas

### User Model
```javascript
{
  id: UUID,
  email: String (unique),
  firstName: String,
  lastName: String,
  phone: String,
  communityId: UUID (foreign key),
  role: Enum["user", "admin", "community_leader"],
  verified: Boolean,
  kycStatus: Enum["pending", "verified", "rejected"],
  created_at: DateTime,
  updated_at: DateTime,
  wallet: {
    balance: Decimal,
    totalDeposited: Decimal,
    totalWithdrawn: Decimal
  }
}
```

### Loan Model
```javascript
{
  id: UUID,
  userId: UUID (foreign key),
  amount: Decimal,
  purpose: String,
  status: Enum["pending", "approved", "rejected", "disbursed", "repaid", "defaulted"],
  appliedDate: DateTime,
  approvalDate: DateTime,
  disbursementDate: DateTime,
  repaymentSchedule: {
    totalInstallments: Integer,
    installmentAmount: Decimal,
    dueDate: [DateTime],
    paidDate: [DateTime],
    status: [Enum["pending", "paid", "overdue"]]
  },
  interestRate: Decimal (percentage),
  collateral: {
    type: String,
    value: Decimal,
    description: String
  },
  approverIds: [UUID],
  communityReviewScore: Decimal (0-100),
  created_at: DateTime,
  updated_at: DateTime
}
```

### Transaction Model
```javascript
{
  id: UUID,
  userId: UUID (foreign key),
  loanId: UUID (foreign key, nullable),
  type: Enum["deposit", "withdrawal", "loan_disbursement", "loan_repayment", "fee"],
  amount: Decimal,
  status: Enum["pending", "completed", "failed", "cancelled"],
  description: String,
  referenceNumber: String (unique),
  fee: Decimal,
  timestamp: DateTime,
  confirmedBy: UUID (admin ID),
  metadata: JSON
}
```

### Community Model
```javascript
{
  id: UUID,
  name: String,
  location: String,
  region: String,
  leaderId: UUID (foreign key),
  established: DateTime,
  memberCount: Integer,
  totalFundsManaged: Decimal,
  activeLoans: Integer,
  repaymentRate: Decimal (percentage),
  verified: Boolean,
  description: String,
  created_at: DateTime,
  updated_at: DateTime
}
```

---

## 3. API Specifications

### Base URL
```
Development: http://localhost:3000/api/v1
Production: https://api.cleanhands-cleanmoney.fam/api/v1
```

### Authentication Endpoints

#### POST /auth/register
```javascript
Request: {
  email: string,
  password: string,
  firstName: string,
  lastName: string,
  phone: string,
  communityId: uuid
}

Response: {
  success: boolean,
  user: User,
  token: JWT,
  expiresIn: 86400
}
```

#### POST /auth/login
```javascript
Request: {
  email: string,
  password: string
}

Response: {
  success: boolean,
  user: User,
  token: JWT,
  refreshToken: JWT,
  expiresIn: 86400
}
```

### Deposit Endpoints

#### POST /deposits
```javascript
Request: {
  amount: number,
  paymentMethod: string,
  description: string
}

Response: {
  success: boolean,
  transaction: Transaction,
  balance: number
}

Status Codes:
- 200: Success
- 400: Invalid amount
- 401: Unauthorized
- 422: Validation failed
```

### Loan Endpoints

#### POST /loans
```javascript
Request: {
  amount: number,
  purpose: string,
  collateral: {
    type: string,
    value: number,
    description: string
  }
}

Response: {
  success: boolean,
  loan: Loan,
  applicationId: uuid
}

Validation Rules:
- Amount: 100-100,000
- Purpose: required, min 10 chars
- Interest rate: 8-15% (based on risk)
```

#### GET /loans
```javascript
Response: {
  success: boolean,
  data: [Loan],
  total: number,
  page: number,
  limit: number
}

Query Parameters:
- status: string (pending, approved, rejected, etc.)
- userId: uuid
- page: integer
- limit: integer
- sortBy: string (date, amount, status)
```

#### GET /loans/:loanId
```javascript
Response: {
  success: boolean,
  data: Loan,
  repaymentSchedule: [RepaymentItem],
  documents: [Document]
}
```

#### PUT /loans/:loanId/status
```javascript
Request: {
  status: string,
  approverNotes: string
}

Response: {
  success: boolean,
  loan: Loan,
  statusChanged: boolean
}

Admin Only:
- Requires role: "admin"
- Log all changes for audit
```

---

## 4. State Management

### Current (useState)
```javascript
const [balance, setBalance] = useState(INITIAL_BALANCE)
const [loans, setLoans] = useState([])
const [transactions, setTransactions] = useState([])
const [notifications, setNotifications] = useState([])
const [isLoading, setIsLoading] = useState(false)
const [stats, setStats] = useState({...})
```

### Recommended (Redux/Zustand)
```javascript
// Redux Structure
store/
├── slices/
│   ├── auth.js (user, isAuthenticated, token)
│   ├── wallet.js (balance, transactions, deposits)
│   ├── loans.js (loans array, filters, pagination)
│   ├── community.js (communities, stats)
│   └── ui.js (notifications, loading states)
├── middleware/
│   └── api.js (API call handling)
└── store.js

// Usage
import { useSelector, useDispatch } from 'react-redux'
const balance = useSelector(state => state.wallet.balance)
const dispatch = useDispatch()
```

---

## 5. Security Architecture

### Authentication & Authorization
```
┌─────────────┐
│   Client    │
└──────┬──────┘
       │ 1. Login (email, password)
       ▼
┌─────────────────────┐
│ Auth Service        │
│ - Verify password   │
│ - Generate JWT      │
└──────┬──────────────┘
       │ 2. Return JWT + Refresh Token
       ▼
┌──────────────────────┐
│ Client Store         │
│ (localStorage/Redux) │
└──────┬───────────────┘
       │ 3. Include JWT in Authorization header
       ▼
┌──────────────────────┐
│ API Gateway          │
│ - Verify JWT         │
│ - Check permissions  │
└──────────────────────┘
```

### Encryption Standards
- **Passwords**: bcrypt (rounds: 12)
- **Data in Transit**: TLS 1.3
- **Sensitive Data at Rest**: AES-256
- **API Keys**: Hashed with SHA-256

### Compliance Checklist
- [ ] GDPR compliance (data privacy)
- [ ] PCI DSS (financial data)
- [ ] KYC/AML (know your customer)
- [ ] Audit logging (all transactions)
- [ ] Rate limiting (DDoS protection)
- [ ] Input validation (injection prevention)
- [ ] CORS configuration
- [ ] Security headers (CSP, X-Frame-Options, etc.)

---

## 6. Deployment Architecture

### Cloud Infrastructure (AWS)
```
┌─────────────────────────────────────────┐
│         AWS CloudFront (CDN)            │
│  (Static assets caching)                │
└──────────────────┬──────────────────────┘
                   │
┌──────────────────▼──────────────────────┐
│    AWS Application Load Balancer        │
│  (SSL/TLS termination)                  │
└──────────────────┬──────────────────────┘
                   │
    ┌──────────────┼──────────────┐
    │              │              │
┌───▼───┐      ┌───▼───┐     ┌───▼───┐
│ ECS 1 │      │ ECS 2 │     │ ECS 3 │ (Auto-scaling group)
│Node.js│      │Node.js│     │Node.js│
└───┬───┘      └───┬───┘     └───┬───┘
    │              │              │
    └──────────────┼──────────────┘
                   │
    ┌──────────────┼──────────────┐
    │              │              │
┌───▼───┐      ┌───▼───┐     ┌───▼───┐
│  RDS  │      │ Redis │     │   S3  │
│(Master)       │Cache │     │Backups│
└───────┘      └───────┘     └───────┘

Terraform for Infrastructure as Code
```

### Deployment Steps
```bash
# 1. Build frontend
npm run build

# 2. Build Docker image
docker build -t clean-hands-api:latest .

# 3. Push to ECR
aws ecr get-login-password | docker login --username AWS --password-stdin $ECR_URI
docker tag clean-hands-api:latest $ECR_URI/clean-hands-api:latest
docker push $ECR_URI/clean-hands-api:latest

# 4. Deploy with Terraform
cd infrastructure
terraform plan
terraform apply

# 5. Run migrations
npm run migrate
```

---

## 7. Testing Strategy

### Unit Tests (Jest)
```javascript
// Example: Loan validation
describe('Loan Validation', () => {
  test('should reject amounts < $100', () => {
    expect(validateLoanAmount(50)).toBe(false)
  })
  
  test('should reject amounts > $100,000', () => {
    expect(validateLoanAmount(150000)).toBe(false)
  })
  
  test('should accept valid amounts', () => {
    expect(validateLoanAmount(5000)).toBe(true)
  })
})
```

### Integration Tests (Cypress)
```javascript
// Example: Loan application workflow
describe('Loan Application Flow', () => {
  it('should submit a loan application', () => {
    cy.visit('/')
    cy.get('[aria-label="Loan amount in dollars"]').type('5000')
    cy.get('[aria-label="Purpose of loan"]').type('Equipment purchase')
    cy.get('[aria-label="Submit loan application"]').click()
    cy.contains('Community review pending').should('be.visible')
  })
})
```

### E2E Tests (Playwright)
```javascript
test('complete loan lifecycle', async ({ page }) => {
  await page.goto('http://localhost:3000')
  await page.fill('[aria-label="Loan amount in dollars"]', '5000')
  await page.fill('[aria-label="Purpose of loan"]', 'Business startup')
  await page.click('[aria-label="Submit loan application"]')
  
  // Wait for approval (2 seconds in demo)
  await page.waitForTimeout(2000)
  
  // Verify approved
  await expect(page.locator('text=approved')).toBeVisible()
})
```

---

## 8. 24-Month Product Roadmap

### Phase 1: MVP (Months 1-3)
- [x] Core deposit functionality
- [x] Basic loan application
- [x] Notification system
- [x] User authentication
- [ ] Admin dashboard
- [ ] KYC verification

### Phase 2: Expansion (Months 4-9)
- [ ] Multi-language support
- [ ] Mobile app (React Native)
- [ ] Advanced reporting
- [ ] Community reviews system
- [ ] Automated underwriting
- [ ] Integration with external lenders

### Phase 3: Scaling (Months 10-18)
- [ ] Blockchain integration (loan history)
- [ ] International expansion
- [ ] API for external partners
- [ ] Machine learning for risk assessment
- [ ] Advanced security (biometrics)
- [ ] Community governance voting

### Phase 4: Sustainability (Months 19-24)
- [ ] Indigenous economic integration
- [ ] Grant management
- [ ] Microfinance networks
- [ ] Economic impact tracking
- [ ] Regulatory certifications
- [ ] Full production deployment

---

## 9. Compliance & Regulations

### Required Certifications
- **SOC 2 Type II** - Data security
- **ISO 27001** - Information security
- **PCI DSS v3.2.1** - Payment card industry
- **HIPAA** - If handling health data (future)

### Regulatory Requirements
- Money Transmitter License (state-dependent)
- Anti-Money Laundering (AML) compliance
- Know Your Customer (KYC) verification
- Consumer Financial Protection Bureau (CFPB) rules
- Fair Lending laws (FCRA, ECOA)

---

## 10. Monitoring & Analytics

### Key Metrics
```javascript
// Dashboard KPIs
const metrics = {
  // Financial
  totalLoansApproved: 0,
  totalFundsDistributed: 0,
  averageLoanSize: 0,
  repaymentRate: 0,
  
  // User
  totalUsers: 0,
  activeUsers: 0,
  userGrowthRate: 0,
  
  // System
  apiResponseTime: 0,
  systemUptime: 0,
  transactionSuccessRate: 0
}
```

### Logging
```javascript
// Structured logging (Winston)
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.json(),
  transports: [
    new winston.transports.File({ filename: 'error.log', level: 'error' }),
    new winston.transports.File({ filename: 'combined.log' })
  ]
})

// Example
logger.info('Loan application submitted', {
  loanId: '123',
  userId: '456',
  amount: 5000,
  timestamp: new Date()
})
```

---

## 11. Disaster Recovery Plan

### Backup Strategy
- **Database**: Daily encrypted backups to S3
- **Application**: Version controlled in Git
- **Secrets**: AWS Secrets Manager

### RTO & RPO
- Recovery Time Objective (RTO): 4 hours
- Recovery Point Objective (RPO): 1 hour

### Failover Process
```bash
# 1. Detect failure
# 2. Activate standby region
# 3. Restore from latest backup
# 4. Verify data integrity
# 5. Update DNS
# 6. Monitor for issues
```
